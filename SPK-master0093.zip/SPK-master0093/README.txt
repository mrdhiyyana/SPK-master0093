**Cara Install**

*)Extract File zip pada folder yang di inginkan.
*)Import file: db.sql pada database yang anda gunakan.
*)Ubah data pada application/config/database.php
|============================================================|
|  'username' => 'root',//Isi dengan username database anda  |
|  'password' => '',//Isi dengan password database anda	     |
|  'database' => 'spk',//Isi nama database anda              |
|============================================================|
Username & password : admin