<?php echo $header;?>
<?php echo $isi;?>
<?php echo $footer;?>